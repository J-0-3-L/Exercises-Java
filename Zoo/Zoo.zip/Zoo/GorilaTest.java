package Zoo;

public class GorilaTest {
    public static void main(String[] args){
        Gorila accion= new Gorila();

        accion.displayEnergy();

        accion.throwSomething();
        accion.throwSomething();
        accion.throwSomething();

        accion.eatBananas();
        accion.eatBananas();

        accion.climb();

        accion.displayEnergy();
    }
}
