package Zoo;

public class Mammal {
    int energyLevel=100;

    public int displayEnergy() {
        System.out.println("\nEnergy level: " + energyLevel+"\n");
        return energyLevel;
    }
}
