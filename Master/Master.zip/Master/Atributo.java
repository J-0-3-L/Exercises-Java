package Master;

public class Atributo {
    int strength=3;
    int stealth=3;
    int intelligence=3;
    int health=100;

}
