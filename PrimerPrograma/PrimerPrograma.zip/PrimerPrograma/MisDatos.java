package PrimerPrograma;
public class MisDatos {
    public static void main(String[] args) {
        String nombre = "Joel";
        int edad = 23;
        String ciudadNatal = "Ica";
        
        System.out.println("Nombre: " + nombre);
        System.out.println("Edad: " + edad);
        System.out.println("Ciudad Natal: " + ciudadNatal);
    }
}
