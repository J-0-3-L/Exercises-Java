package ZooDos;

public class Especimen {
    int energia=300;

    public int displayEnergy(){
        System.out.println("\nEnergia General: " + energia+"\n");
        return energia;
    }
}
