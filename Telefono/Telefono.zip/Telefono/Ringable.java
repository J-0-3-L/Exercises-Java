package Telefono;

public interface Ringable {
    String ring();
    String unlock();
}


